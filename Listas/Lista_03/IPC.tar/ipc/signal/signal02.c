#include <signal.h>
#include <stdio.h>

main()
{
	int i=0;

	while(1){ printf("%d\n",i++); }
} 
